//
//  Globale.swift
//  mapApplication
//
//  Created by sundus on 17/09/1440 AH.
//  Copyright © 1440 sundus. All rights reserved.
//

import Foundation

class Global {
    
    static var shared = Global()

    var studentLocations: [StudentLoc]?
}
